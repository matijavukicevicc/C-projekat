#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct cvor CVOR;
typedef CVOR* PCVOR;
struct cvor {
	int info;
	PCVOR sledeci;
};

int nemaBroj(int*niz,int duzina,int broj) {
	int i;

	for (i = 0; i < duzina; i++)
		if (*(niz+i) == broj)
			return 0;

	return 1;
}

int daLiSeNalaziUSporednojDijagonali2(int mat[5][5],int broj, int n) {
	int i;
	int j;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			if ((i + j) == (n - 1) && mat[i][j] == broj)
				return 1;
		}
	}
	return 0;
}

int zbirCifara(int broj) {
	int zbir=0;
	while (broj!=0) {
		zbir = zbir + broj % 10;
		broj = broj / 10;
	}
	return zbir;
}

void prikaziNajveciOdN(int n) {
	
	int i = 1;
	int broj;
	int zbirCifaraBroja;
	int maksBroj = 0;

	while (i<=n) {
		printf("unesite broj");
		scanf("%d", &broj);
		zbirCifaraBroja = zbirCifara(broj);
		if(zbirCifaraBroja>maksBroj)
			maksBroj = broj;
	}
	printf("maks. broj:%d", maksBroj);
}

int daLiJePalindrom(int broj){
	
	int kopija = broj;
	int trenutnaPoslednjaCifra;
	int trenutniOblikObrnutogBroja=0;

	while (broj>0) {
		trenutnaPoslednjaCifra = broj % 10;
		trenutniOblikObrnutogBroja = trenutniOblikObrnutogBroja * 10 +
			trenutnaPoslednjaCifra;
		broj = broj / 10;
	}
	
	if (kopija == trenutniOblikObrnutogBroja)
		return 1;


	return 0;
}

void uKrug(int*mat,int brojKolona,int brojrRedova,int*niz) {
	int i=0;
	int j=0;
	int t=0;
	do {
		if (i==0 && j< brojKolona) {
			*(mat + i * brojKolona + j) = *(niz + t);
			j++;
			t++;
		}
		if (j == brojKolona && i!=(brojrRedova-1)) {
			i++;
			*(mat + i * brojKolona + j) = *(niz + t);
		}
	}while (i != j);
}

void ubaciUSortListu(PCVOR *glava,int broj) {
	
	PCVOR pom = *glava;
	
	if (*glava == NULL) {
		PCVOR novi = malloc(sizeof(CVOR));
		novi->info = broj;
		*glava = novi;
		(*glava)->sledeci = novi;
		return;
	}
	
	while (pom->sledeci != NULL) {
		if (pom->sledeci->info < broj) {
			PCVOR novii = malloc(sizeof(CVOR));
			novii->info = broj;
			novii->sledeci = pom->sledeci;
			pom->sledeci = novii;
			return;
		}

		pom = pom->sledeci;
	}
	PCVOR noviii = malloc(sizeof(CVOR));
	noviii->info = broj;
	pom->sledeci = noviii;
	noviii->sledeci = NULL;
}

void novuOdPrveIDruge(PCVOR *glava, PCVOR *glava2) {
	
	PCVOR pom = *glava;
	PCVOR pom2 = *glava2;
	PCVOR pomocni;

	while (pom!=NULL) {
		pomocni = pom->sledeci;
		pom->sledeci = pom2;
		pom2->sledeci = pomocni;
		pom = pom->sledeci;
		pom2 = pom2->sledeci;
	}
	
}

void prvoProstiBrojevi(PCVOR *glava) {
	
	PCVOR pom = *glava;
	PCVOR pom2 = *glava;
	int broj = 0;
	
	while (pom != NULL) {
		if (daLiJeProstBroj(pom->info) == 0) {
			int brojZaZamenu = pom->sledeci->info;
			while (pom2->sledeci!=NULL) {
				
				pom2 = pom2->sledeci;
			}
			pom->info = pom2->info;
			pom2->info = brojZaZamenu;
		}
	}
}

void unesiString() {
	char string[100];
	char znak;
	int i = 0;;
	printf("unesite string");
	
	while (1) {
		znak = getchar();
		getchar();
		if (znak == '-')
			break;
		else {
			string[i] = znak;
			i++;
		}
	} 
}

void pomeranjeNizaUlevoOdIndeksa(char*niz,int indeks) {
	
	while (*(niz + indeks) != '\0') {
		*(niz + indeks) = *(niz + indeks + 1);
		indeks++;
	}
}

int kolikoImaElemenataSaDatimBrojem(char*string,int broj) {
	int i = 0;
	int brojPojavljivanja=0;
	while (*(string + i) != '\0') 
		if (*(string + i) == broj) {
			brojPojavljivanja++;
			i++;
		}
	return brojPojavljivanja;
}

int daLinemaZatvorenePreOtvoreneZagrade(char*string) {
	int i = 0;
	int j = 0;

	while (*(string+i)!='\0') {
		if (*(string + i) == ')') {
			while (*(string + i + j) != '\0') {
				if (*(string + i + j) == '(')
					return 0;
				j++;
			}
		}
		i++;
	}
	return 1;
}

int daLiSuAnagrami(char*string1,char*string2) {
	int i = 0;
	while (*(string1 + i) != '\0') 
		if(kolikoImaElemenataSaDatimBrojem(string1, *(string1 + i))<
			kolikoImaElemenataSaDatimBrojem(string2, *(string2 + i)))
			return 0;
	return 1;
}

void kompreseijaStringa(char*string) {
	char znak1;
	char znak2;
	int i = 0;
	int brojPojavljivanjaZnaka;
	int broj2;
	int indekOdKogPomeriti;
	int brojPomeranjaDoSada = 0;
	int kolkoPutaTrebaPomeriti;

	while (*(string + i) != '\0') {
		znak1 = *(string + i);
		brojPojavljivanjaZnaka = 1;
		znak2 = *(string + i + 1);
		broj2 = 0;
		while (znak2 == znak1) {
			brojPojavljivanjaZnaka++;
			broj2++;
			znak2 = *(string + i + 1 + broj2);
		}
		if (brojPojavljivanjaZnaka > 3) {
			*(string + i) = '(';
			*(string + i + 1) = brojPojavljivanjaZnaka + '0';
			*(string + i + 2) = ')';
			kolkoPutaTrebaPomeriti = brojPojavljivanjaZnaka - 3;
			indekOdKogPomeriti = i + brojPojavljivanjaZnaka-1;
			brojPomeranjaDoSada = 0;
			while (brojPomeranjaDoSada != kolkoPutaTrebaPomeriti) {
				pomeranjeNizaUlevoOdIndeksa(string, indekOdKogPomeriti);
				indekOdKogPomeriti--;
				brojPomeranjaDoSada++;
			}
			i = i + 4;
		}
		else
			i = i + brojPojavljivanjaZnaka;
	}
	int d = i;
	for (i = 0; i <= d; i++) {
		printf("%c", *(string + i));
	}
}

int daLiSeNalaziUSporednojDijagonali(int *mat, int broj, int n) {
	int i;
	int j;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			if ((i + j) == (n - 1) && *(mat + i * n + j)==broj) 
				return 1;
		}
	}
	return 0;
}

int dLiSuDijagonaleIste(int *mat) {
	int i;
	int j;
	int n;
	printf("unesite dimenziju kvadratne matrice:");
	scanf("%d", &n);
	
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			if (i == j
				&& daLiSeNalaziUSporednojDijagonali(mat, *(mat + i * n + j), n)
				== 0) {
				printf("nisu iste");
				return 0;
			}
		}
	}
	printf("iste su");
	return 1;
}	

void presekGISDijagonale(int*mat, int n, int*niz) {
	int i;
	int j;
	int broj = 0;

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			if (i == j && 
				nemaDuplikata2(niz, n, *(mat + i * n + j)) == 1 &&
				daLiSeNalaziUSporednojDijagonali(mat, *(mat + i * n + j),n)==1) {
				*(niz + broj) = *(mat + i * n + j);
				broj++;
			}
		}
	}
}

void unijaGlavneISporedneDijagonale(int*mat,int n,int*niz) {
	int i;
	int j;
	int broj = 0;

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			if (i == j && nemaDuplikata2(niz,n, *(mat + i * n + j))==1) {
				*(niz + broj)= *(mat + i * n + j);
				broj++;
			}	
		}
	}
	
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			if ((i +j)==(n-1) && nemaDuplikata2(niz, n, *(mat + i * n + j)) == 1) {
				*(niz + broj) = *(mat + i * n + j);
				broj++;
			}
		}
	}
	
}

int daLiSeNeNalaziUKoloni(int mat[5][5],int broj,int kolona) {
	int i;
	for (i = 0; i < 5; i++) 
		if (mat[i][kolona] == broj)
			return 0;

	return 1;
}

int daLiNemaDuplikata(int niz[10], int broj) {
	int i;
	
	for (i = 0; i < 10; i++)
		if (niz[i] == broj)
			return 0;

	return 1;
}

void presekDveKolone(int mat[5][5], int kolona1, int kolona2) {
	int i;
	int niz[10];
	int broj = 0;
	for (i = 0; i < 5; i++) {
		if (daLiNemaDuplikata(niz, mat[i][kolona1]) == 1 &&
			daLiSeNeNalaziUKoloni(mat, mat[i][kolona1],kolona2==0)) {
			niz[broj] = mat[i][kolona1];
			broj++;
		}
	}
}

void unijaDveKoloneMatUNovNiz(int mat[5][5],int kolona1, int kolona2) {
	int i;
	int niz[10];
	int broj = 0;
	for (i = 0; i < 5; i++) {
		if (daLiNemaDuplikata(niz, mat[i][kolona1])==1) {
			niz[broj] = mat[i][kolona1];
			broj++;
		}
	}
	for (i = 0; i < 5; i++) {
		if (daLiNemaDuplikata(niz, mat[i][kolona2]) == 1) {
			niz[broj] = mat[i][kolona2];
			broj++;
		}
	}
}

void pomeriElementeNizaCiklicno(int *x) {
	
	int i;
	int pom = *x;
	printf("\npom=%d\n",  *x );
	for (i = 0; i < 8; i++) {
			*(x+i) = *(x+ i + 1);
	}
	*(x+8) = pom;	
}

void ciklicnoULevoMat() {
	
	int niz[10];
	int i;
	for (i = 0; i < 9; i++) {
		printf("niz[%d]= ", i);
		scanf("%d", &niz[i]);
	}
	niz[9] = 0;
	int mat[9][9];
	int j;
	for (i = 0; i < 9; i++) {
		for (j = 0; j < 9; j++) {
			mat[i][j] = niz[j];
		}
		pomeriElementeNizaCiklicno(&niz);
	}

	for (i = 0; i < 9; i++) {
		for (j = 0; j < 9; j++) {
			printf("\nmat[%d][%d]=%d\n",i,j, mat[i][j]);
		}
	}
}

int daLiJeProstBroj(int broj) {
	int i;
	for (i = 2; i < broj; i++) 
		if (broj%i == 0) 
			return 0;
	return 1;
}

void prikaziNajduziPodnizPravihProstihBrojeva(int*niz, int duzina) {

	int i;
	int duzinaTrenutnogMaks;;
	int duzinaMaksPodniza = 0;
	int indeksPocetkaTrenMaks;
	int indeksKrajaTrenMaks;
	int indeksPocetkaMaks;
	int indeksKrajaMaks;
	int signal1 = 0;;
	int signal2 = 0;

	for (i = 0; i < duzina; i++) {
		if (daLiJeProstBroj(*(niz+i))==1) {
			if (i == 0 || *(niz + i - 1) >= 10) {
				indeksPocetkaTrenMaks = i;
				signal1 = 1;
			}
			if (*(niz + i + 1) >= 10 || i == (duzina - 1)) {
				indeksKrajaTrenMaks = i;
				signal2 = 1;
			}
			if (signal1 == 1 && signal2 == 1) {
				signal1 = 0;
				signal2 = 0;
				duzinaTrenutnogMaks =
					indeksKrajaTrenMaks - indeksPocetkaTrenMaks + 1;
				if (duzinaTrenutnogMaks > duzinaMaksPodniza) {
					duzinaMaksPodniza = duzinaTrenutnogMaks;
					indeksPocetkaMaks = indeksPocetkaTrenMaks;
					indeksKrajaMaks = indeksKrajaTrenMaks;
				}
			}
		}

	}
	for (i = indeksPocetkaMaks; i <= indeksKrajaMaks; i++)
		printf("\n%d\n", *(niz + i));
}

void prikaziNajduziPodnizProstihBrojeva (int*niz,int duzina){
	
	int i;
	int duzinaTrenutnogMaks;;
	int duzinaMaksPodniza=0;
	int indeksPocetkaTrenMaks;
	int indeksKrajaTrenMaks;
	int indeksPocetkaMaks;
	int indeksKrajaMaks;
	int signal1 = 0;;
	int signal2=0;

	for (i = 0; i < duzina; i++) {
		if (*(niz + i) < 10) {
			if (i == 0 || *(niz + i - 1) >= 10) {
				indeksPocetkaTrenMaks = i;
				signal1 = 1;
			}
			if (*(niz + i + 1) >= 10||i==(duzina-1)) {
				indeksKrajaTrenMaks = i;
				signal2 = 1;
			}
			if (signal1 == 1 && signal2 == 1) {
				signal1 = 0;
				signal2 = 0;
				duzinaTrenutnogMaks =
					indeksKrajaTrenMaks-indeksPocetkaTrenMaks + 1;
				if (duzinaTrenutnogMaks > duzinaMaksPodniza) {
					duzinaMaksPodniza = duzinaTrenutnogMaks;
					indeksPocetkaMaks = indeksPocetkaTrenMaks;
					indeksKrajaMaks = indeksKrajaTrenMaks;
				}
			}
		}
		
	}
	for (i = indeksPocetkaMaks; i <= indeksKrajaMaks; i++)
		printf("\n%d\n", *(niz + i));
}

int main() {
	int a = 2;
	int b = 5;
	int c = 7;
	int d = 65;
	if (a<c>b) {
		printf("\nda\n");
	}
	
	char nizZnakova [] = { 'a','a','a','a','s','s','n','n','n','n'
		,'j','j','i','\0'};
	kompreseijaStringa(&nizZnakova);
	int mat[5][5] = {
		1,5,6,8,1,
		7,1,8,1,6,
		2,6,1,7,7,
		8,1,4,1,5,
		1,6,5,7,4
	};
	dLiSuDijagonaleIste(mat);
	int niz[10] = { 5,2,67,45,1,8,4,1000,299,0 };
	prikaziNajduziPodnizProstihBrojeva(&niz,10);
	ciklicnoULevoMat();
	system("pause");
	return 0;
}
